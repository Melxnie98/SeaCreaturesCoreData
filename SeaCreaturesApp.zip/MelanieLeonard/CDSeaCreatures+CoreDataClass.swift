//
//  CDSeaCreatures+CoreDataClass.swift
//  CoreDataSeaCreatures
//
//  Created by Melanie Kate Leonard on 27/03/2023.
//
//

import Foundation
import CoreData


public class CDSeaCreatures: NSManagedObject{
  
}

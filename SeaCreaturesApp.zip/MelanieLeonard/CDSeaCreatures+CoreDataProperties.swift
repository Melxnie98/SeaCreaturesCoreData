//
//  CDSeaCreatures+CoreDataProperties.swift
//  CoreDataSeaCreatures
//
//  Created by Melanie Kate Leonard on 10/04/2023.
//
//

import Foundation
import CoreData


extension CDSeaCreatures {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDSeaCreatures> {
        return NSFetchRequest<CDSeaCreatures>(entityName: "Animal")
    }

    @NSManaged public var habitat: String?
    @NSManaged public var harm: String?
    @NSManaged public var image: String?
    @NSManaged public var lifespan: String?
    @NSManaged public var name: String?
    @NSManaged public var nomenclature: String?
    @NSManaged public var safe: String?
    @NSManaged public var status: String?
    @NSManaged public var video: String?
    @NSManaged public var www: String?
    @NSManaged public var favourites: Bool

}

extension CDSeaCreatures : Identifiable {

}

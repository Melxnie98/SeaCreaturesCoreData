//
//  AddUpdateViewController.swift
//  CoreDataPeopleInformation
//
//  Created by Melanie Kate Leonard on 13/03/2023.
//

import UIKit
import CoreData

class AddUpdateViewController: UIViewController, UIImagePickerControllerDelegate & UINavigationControllerDelegate {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Populate the fields with data from managed object
        if pManagedObject != nil{
            nameTextField.text=pManagedObject.name
            nomenclatureTextField.text=pManagedObject.nomenclature
            habitatTextField.text=pManagedObject.habitat
            imageTextField.text=pManagedObject.image
            wwwTextField.text=pManagedObject.www
            harmTextField.text=pManagedObject.harm
            videoTextField.text=pManagedObject.video
            statusTextField.text=pManagedObject.status
            
            //get img to img view
            if pManagedObject.image != nil{
                getImage(name: pManagedObject.image!)
            }
            
        }
    }
    
    //MARK: - core dat
    //line every time need new context
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var pEntity : NSEntityDescription!
    var pManagedObject : CDSeaCreatures!
    
    func addPerson(){
        //create a new managed object
        //call initialiser of cdppeople - need entity
        pEntity = NSEntityDescription.entity(forEntityName: "Animal", in: context)
        pManagedObject = CDSeaCreatures(entity:pEntity, insertInto:context)
        
        //Populate it w data from fields
        pManagedObject.name=nameTextField.text
        pManagedObject.nomenclature=nomenclatureTextField.text
        pManagedObject.www=wwwTextField.text
        pManagedObject.image=imageTextField.text
        pManagedObject.habitat=habitatTextField.text
        pManagedObject.harm = harmTextField.text
        pManagedObject.video=videoTextField.text
        pManagedObject.status=statusTextField.text
        
        //Context to save it
        do{
            try context.save()
        }catch{
            print("Context cannot save a new object.")
        }
        //Put or save img to document
        let image = pickedImageView.image
        if image != nil && pManagedObject.image != nil{
            putImage(name: pManagedObject.image!)
        }
        
        
    }
    
    func updatePerson(){
        //Populate it w data from fields
        pManagedObject.name=nameTextField.text
        pManagedObject.nomenclature=nomenclatureTextField.text
        pManagedObject.www=wwwTextField.text
        pManagedObject.image=imageTextField.text
        pManagedObject.habitat=habitatTextField.text
        pManagedObject.harm = harmTextField.text
        pManagedObject.video=videoTextField.text
        pManagedObject.status=statusTextField.text
        
        
        //Context to save it
        do{
            try context.save()
        }catch{
            print("Context cannot save a new object.")
        }
        //Put or save img to document
        let image = pManagedObject.image
        if image != nil && pManagedObject.image != nil{
            putImage(name:pManagedObject.image!)
        }
        
    }
    
    //MARK: - out and ap
    

    @IBOutlet weak var pickedImageView: UIImageView!
    @IBAction func pickedImageAction(_ sender: Any) {
        imagePicker.sourceType = .savedPhotosAlbum
        imagePicker.allowsEditing = false
        imagePicker.delegate = self
        
        present(imagePicker,animated: true, completion: nil)
    }
    
    //pivker and img methods
    let imagePicker = UIImagePickerController()
    
    func getImage(name:String){
          // get the image name from documents
          let imagePath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(name)
          let image = UIImage(contentsOfFile: imagePath)
   
          // place it to image view
          pickedImageView.image = image
      }

    func putImage(name:String){
        //get img name from documents
        let imagePath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true) [0]as NSString).appendingPathComponent(name)
        let fm = FileManager.default
        let image = pickedImageView.image
        let data = image?.pngData()
        
        //fm save data
        fm.createFile(atPath: imagePath, contents: data)
        
    
        //place to img view
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //get img from info
        let image = info[UIImagePickerController.InfoKey.originalImage] as! UIImage
        
        //place to imageview
        pickedImageView.image = image
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true)
    }
    
    @IBOutlet weak var videoTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var nomenclatureTextField: UITextField!
    @IBOutlet weak var habitatTextField: UITextField!
    @IBOutlet weak var wwwTextField: UITextField!
    @IBOutlet weak var imageTextField: UITextField!
    
   
    @IBOutlet weak var statusTextField: UITextField!
    @IBOutlet weak var harmTextField: UITextField!
    
    @IBAction func addUpdateAction(_ sender: Any) {
        // call either update or add
        if pManagedObject == nil{
            addPerson()
        }else{
            updatePerson()
        }
        //Go back to the table
        navigationController?.popViewController(animated: true)
        //automatically goes back to 1st screen
    }
   
}


//
//  Animals.swift
//  
//
//  Created by Melanie Leonard on 21/02/2023.
//

import Foundation
import CoreData

class  Animals
{
    var data : [Animal]!
   
    init(fromXML : String)
    {
        // make an XMLBandParser, and begin parsing
        let parser = AnimalsXMLParser(name: fromXML)
        parser.beginParsing()
        
        // init data
        self.data = parser.animals
        
    }
    
    // functions
    func getAnimal(index:Int)->Animal
    {
        return data[index]
    }
    
    func getCount()->Int
    {
        return data.count
    }
    func getNames() -> [String]{
        // make an empty array
        var names = [String]()
        
        // traverse the people data and place their names in array
        for animalData in data{
            names.append(animalData.name)
        }
        
        return names
    }
    
}

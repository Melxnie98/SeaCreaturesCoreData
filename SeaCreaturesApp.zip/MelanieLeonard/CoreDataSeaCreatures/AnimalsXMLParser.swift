//
//  seaCreaturesXMLParser.swift
//  
//
//  Created by Melanie Leonard on 21/02/2023.
//

import Foundation
import UIKit
import CoreData

class AnimalsXMLParser : NSObject, XMLParserDelegate
{
    // properties
    var name : String
    init(name : String){self.name = name}
    
    // some variables for parsing
    var animalName, animalNomenclature, animalLifespan, animalHabitat, animalStatus, animalImage, animalSafe, animalHarm, animalWww, animalVideo: String! // collect data
    let tags = ["NAME", "NOMENCLATURE", "LIFESPAN", "HABITAT", "STATUS", "IMAGE", "SAFE", "HARM", "WWW", "VIDEO"]
    
   // var passSectionId : Int = -1
    var passElementId : Int = -1
    var passData : Bool = false // find tag
    
    
    var animalData : Animal!
    var animals = [Animal]() // to collect person object when needed
    
    var parser = XMLParser()
  
   
    
    func parser(_ parser: XMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String] = [:])
    {
        // reset the spy vars for tags
        if tags.contains(elementName)
        {
            // set spies for the appropriate tag
            passElementId = tags.firstIndex(of: elementName)!
            passData = true
        }
    }
   
    func parser(_ parser: XMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        // reset spies for new pull
        
            if tags.contains(elementName)
                
            {
                // set spies for the appropriate tag
                passElementId = -1
                passData = false
            }
            
            // test if tag is </ANIMAL>
            if elementName == "ANIMAL"
            {
                // make a new person and add it to people
                let animal = Animal(name: animalName, nomenclature:animalNomenclature, lifespan:animalLifespan, habitat:animalHabitat, status:animalStatus, image: animalImage, safe:animalSafe, harm:animalHarm, www: animalWww, video:animalVideo)
                
                animals.append(animal)
            }
            
        }
 
    func parser(_ parser: XMLParser, foundCharacters string: String)
    {
        // place data that is obtained from between tags
        if passData
        {
            switch passElementId
            {
            case 0 : animalName = string
            case 1 : animalNomenclature = string
            case 2 : animalLifespan = string
            case 3 : animalHabitat = string
            case 4 : animalStatus = string
            case 5 : animalImage = string
            case 6 : animalSafe = string
            case 7 : animalHarm = string
            case 8 : animalWww = string
            case 9 : animalVideo = string
           
            default : break
            }
        }
    }
    
    func beginParsing()
    {
        // find the file path
        let bundleURL = Bundle.main.bundleURL
        let fileURL = URL(string: self.name, relativeTo: bundleURL)
        
        parser = XMLParser(contentsOf: fileURL!)!
        
        //set delegate ->  parse
        parser.delegate = self
        parser.parse()
    }
    
}

//
//  WebViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit
import WebKit
import CoreData

class WebViewController: UIViewController , WKUIDelegate{
    var animalData : Animal!
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var pEntity : NSEntityDescription!
    var pManagedObject : CDSeaCreatures!
    var webView: WKWebView!

    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()

        // Do any additional setup after loading the view.
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
       view = webView
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = pManagedObject.www

        // Do any additional setup after loading the view.
        let web = NSURL(string: pManagedObject.www!)
        let requestObj = NSURLRequest(url: web! as URL )
        webView.load(requestObj as URLRequest)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

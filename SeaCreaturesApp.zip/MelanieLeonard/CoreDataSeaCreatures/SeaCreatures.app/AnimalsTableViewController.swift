//
//  AnimalsTableViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit

class AnimalCells:UITableViewCell{
    
    @IBOutlet weak var cellLabel: UILabel!
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var cellLabel2: UILabel!
}
class AnimalsTableViewController: UITableViewController {

    var animalsData : Animals!
   
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // make data set title
        self.title = "Sea Creatures"
        animalsData = Animals(fromXML: "XMLanimals.xml")
        super.viewDidLoad()
           
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return animalsData.getCount()
    }
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AnimalCells

        // Configure the cell with the band data
        let animal = animalsData.getAnimal(id: indexPath.row)
        cell.cellLabel?.text = animal.name
        cell.cellLabel2?.text = animal.nomenclature
        cell.cellImage?.image = UIImage(named: "image/" + animal.image)
        cell.cellImage?.contentMode = UIView.ContentMode.scaleAspectFill
        
       

        return cell
    }
    

  
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?)
     {
         // get index path for cell
         let indexPath = tableView.indexPath(for: sender as! UITableViewCell)
         // Get the new view controller using segue.destinationViewController.
         let destination = segue.destination as! AnimalViewController
         // Pass chosen object to the new view.
         destination.animalData = animalsData.getAnimal(id:(indexPath?.row)!)
     }

}

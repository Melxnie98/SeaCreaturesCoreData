//
//  AnimalViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit
import AVKit

class AnimalViewController: UIViewController {

    
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var nomenclatureLabel: UILabel!
    
    @IBAction func moreInfo(_ sender: UIButton) {
    }
   
    @IBOutlet weak var safeLabel: UILabel!
    
    @IBOutlet weak var harmLabel: UILabel!
    
    var animalData : Animal!
    var animalsData: Animals!
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "webSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! WebViewController
            
            // Pass the selected object to the new view controller.
            destinationController.animalData = self.animalData
        }
        if segue.identifier == "detailsSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! DetailsViewController
            
            // Pass the selected object to the new view controller.
            destinationController.animalData = self.animalData
        }
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        //set Title
        self.title = animalData.name

        // get the data
        
        
        nomenclatureLabel.text = animalData.nomenclature
        imageView.image = UIImage(named: "image/" + animalData.image)
        safeLabel.text = animalData.safe
        harmLabel.text = animalData.harm
        
       
    }

    
    

   
  

   
    
  
}
   

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */



//
//  DetailsViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit


class DetailsViewController: UIViewController {
    
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var nomenclatureLabel: UILabel!
    
    @IBOutlet weak var habitatLabel: UILabel!
    
    @IBOutlet weak var lifespanLabel: UILabel!
    
    @IBAction func moreInfo(_ sender: UIButton) {
    }
    
    var animalData : Animal!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //set Title
        self.title = "Facts"
        
        // get the data
        nameLabel.text = animalData.name
        nomenclatureLabel.text = animalData.nomenclature
        habitatLabel.text = animalData.habitat
        lifespanLabel.text = animalData.lifespan
        statusLabel.text = animalData.status
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "detailsToWebSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! WebViewController
            
            // Pass the selected object to the new view controller.
            destinationController.animalData = self.animalData
        }
        if segue.identifier == "videoSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! VideoViewController
            
            // Pass the selected object to the new view controller.
            destinationController.animalData = self.animalData
        }
        
        
    }
    
}

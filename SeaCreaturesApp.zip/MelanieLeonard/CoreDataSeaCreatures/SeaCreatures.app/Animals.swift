//
//  Animals.swift
//  
//
//  Created by Melanie Leonard on 21/02/2023.
//

import Foundation

class  Animals
{
    var data : [Animal] = []
    var sections : String?
   
    init(fromXML : String)
    {
        // make an XMLBandParser, and begin parsing
        let parser = AnimalsXMLParser(name: fromXML)
        parser.beginParsing()
        
        // init data
        self.data = parser.animals
        
    }
    
    // functions
    func getAnimal(id:Int)->Animal
    {
        return data[id];
    }
    
    func getCount()->Int
    {
        return data.count
    }
    
}

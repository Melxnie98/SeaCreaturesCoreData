//
//  VideoViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 10/03/2023.
//

import UIKit
import WebKit

class VideoViewController: UIViewController , WKUIDelegate {
    var animalData : Animal!
    var videoView: WKWebView!

    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()

        // Do any additional setup after loading the view.
        videoView = WKWebView(frame: .zero, configuration: webConfiguration)
        videoView.uiDelegate = self
        view = videoView
            
        }
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = animalData.video

        // Do any additional setup after loading the view.
        let video = URL(string: animalData.video)
        let requestObj = URLRequest(url: video as! URL )
        videoView.load(requestObj as URLRequest)
            
        }
        
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

//
//  AnimalViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit
import AVKit
import CoreData

class AnimalViewController: UIViewController,NSFetchedResultsControllerDelegate{
    
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var pEntity : NSEntityDescription!
    var pManagedObject : CDSeaCreatures!
    
    @IBOutlet weak var fabouriteLabel: UILabel!
    @IBOutlet weak var favSwitch: UISwitch!
    @IBOutlet weak var imageView: UIImageView!
    
    @IBAction func switchChanged(_ sender: UISwitch) {
        if favSwitch.isOn{
            pManagedObject.favourites.toggle()
            do{
                try context.save()
            } catch {
                print("Error saving context: \(error)")
            }
            
        }else{
            pManagedObject.favourites.toggle()
            do{
                try context.save()
            } catch {
                print("Error saving context: \(error)")
            }
        }
    }
    
    @IBOutlet weak var nomenclatureLabel: UILabel!
    
    @IBAction func moreInfo(_ sender: UIButton) {
    }
    
    @IBOutlet weak var safeLabel: UILabel!
    
    @IBOutlet weak var harmLabel: UILabel!
    
    override func viewDidLoad() {
        
        //set Title
        super.viewDidLoad()
        self.title = pManagedObject.name
        
        // get the data
        nomenclatureLabel.text = pManagedObject.nomenclature
        imageView.image = UIImage(named: pManagedObject.image!)
        safeLabel.text = pManagedObject.safe
        harmLabel.text = pManagedObject.harm
        if pManagedObject.favourites == true{
            favSwitch.isOn = true
            
        }
            
        }
        
        // make the frc and perform fetch
        //frc = NSFetchedResultsController(fetchRequest: fetchRequest(), managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        // do{
        //try frc.performFetch()
        //}catch{
        // print("frc cannot fetch")
        //}
        
        // setup frc delegate
        // frc.delegate = self
    
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "webSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as? WebViewController
            
            // get the index path from sender
            //let indexPath = tableView.indexPath(for: (sender as? AnimalCells)!)
            
            // get the managed object from frc
            //pManagedObject = frc.object(at: indexPath!) as? CDSeaCreatures
            
            // Pass the selected object to the new view controller.
            destinationController?.pManagedObject = pManagedObject
            
        }
        if segue.identifier == "detailsSegue"{
            let destinationController = segue.destination as! DetailsViewController
            //pManagedObject = frc.object(at: indexPath!) as? CDSeaCreatures
            
            // Pass the selected object to the new view controller.
            destinationController.pManagedObject = pManagedObject
        }
        if segue.identifier == "editSegue"{
            let destinationController = segue.destination as! AddUpdateViewController
            //pManagedObject = frc.object(at: indexPath!) as? CDSeaCreatures
            
            // Pass the selected object to the new view controller.
            destinationController.pManagedObject = pManagedObject
        }
        
        
        
    }
    
    
    
    
}

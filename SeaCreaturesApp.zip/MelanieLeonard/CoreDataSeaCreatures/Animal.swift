//
//  Animal.swift
//  
//
//  Created by Melanie Leonard on 21/02/2023.
//

import Foundation

class Animal
{
    // properties
   
    var name : String = ""
    var nomenclature : String = ""
    var lifespan : String = ""
    var habitat : String = ""
    var status : String = ""
    var image : String = ""
    var safe : String = ""
    var harm : String = ""
    var www : String = ""
    var video : String = ""
  
    
    init(name:String, nomenclature:String, lifespan:String, habitat:String, status:String, image:String, safe:String, harm:String, www:String, video:String)
    {
     
        self.name = name
        self.nomenclature = nomenclature
        self.lifespan = lifespan
        self.habitat = habitat
        self.status = status
        self.image = image
        self.safe = safe
        self.harm = harm
        self.www = www
        self.video = video
    }
}

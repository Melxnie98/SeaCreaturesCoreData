//
//  DetailsViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit


class DetailsViewController: UIViewController {
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var pManagedObject : CDSeaCreatures!
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var nomenclatureLabel: UILabel!
    
    @IBOutlet weak var habitatLabel: UILabel!
    
    @IBOutlet weak var lifespanLabel: UILabel!
    
    @IBAction func moreInfo(_ sender: UIButton) {
    }
    
    var animalData : Animal!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //set Title
        self.title = "Facts"
        
        // get the data
        nameLabel.text = pManagedObject.name
        nomenclatureLabel.text = pManagedObject.nomenclature
        habitatLabel.text = pManagedObject.habitat
        lifespanLabel.text = pManagedObject.lifespan
        statusLabel.text = pManagedObject.status
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "detailsToWebSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! WebViewController
            
            // Pass the selected object to the new view controller.
            destinationController.pManagedObject = pManagedObject
        }
        if segue.identifier == "videoSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as! VideoViewController
            
            // Pass the selected object to the new view controller.
            destinationController.pManagedObject = pManagedObject
        }
        
        
    }
    
}

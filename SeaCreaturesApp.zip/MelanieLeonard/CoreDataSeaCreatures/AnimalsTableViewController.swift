//
//  AnimalsTableViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit
import CoreData

class AnimalCells:UITableViewCell{
    
    
    @IBOutlet weak var cellLabel: UILabel!
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var cellLabel2: UILabel!
    
    
    
}




class AnimalsTableViewController: UITableViewController, NSFetchedResultsControllerDelegate{
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    var pManagedObject : CDSeaCreatures!
    var frc : NSFetchedResultsController<NSFetchRequestResult>!
    var animalsData : [CDSeaCreatures]!
    var pEntity : NSEntityDescription!
   
    
    
    func fetchRequest() -> NSFetchRequest<NSFetchRequestResult>{
        // create a request
 
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Animal")

        // sort the results
        let sorting1 = NSSortDescriptor(key: "name", ascending: true)
        let sorting2 = NSSortDescriptor(key: "nomenclature", ascending: true)
        let sorting3 = NSSortDescriptor(key: "favourites", ascending: true)
        
        request.sortDescriptors = [sorting1, sorting2,sorting3]
        return request
    }
    
    
   
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // make the frc and perform fetch
        frc = NSFetchedResultsController(fetchRequest: fetchRequest(), managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        
        frc.delegate = self
        do{
            try frc.performFetch()
        }catch{
            print("frc cannot fetch")
        }
        
        // setup frc delegate
        //frc.delegate = self
        if frc.sections![0].numberOfObjects > 0 {
            
            print("You have data.")
        }else{
            let animalsData = AnimalsXMLParser(name:"XMLanimals.xml")
            animalsData.beginParsing()
            //let CDanimalsData = [Animal]?.self
            let animalsDataArray = animalsData.animals
            for animal in animalsDataArray {
               
                pEntity = NSEntityDescription.entity(forEntityName: "Animal", in: context)
                pManagedObject = CDSeaCreatures(entity: pEntity, insertInto: context)
                
                pManagedObject.name = animal.name
                pManagedObject.nomenclature = animal.nomenclature
                pManagedObject.lifespan = animal.lifespan
                pManagedObject.habitat = animal.habitat
                pManagedObject.status = animal.status
                pManagedObject.image = animal.image
                pManagedObject.safe = animal.safe
                pManagedObject.harm = animal.harm
                pManagedObject.www = animal.www
                pManagedObject.video = animal.video
                pManagedObject.favourites = false
                //animalsDataArray.append[pManagedObject]
                do{
                    try context.save()
                }catch{
                    print("Context cant save new obj")
                }
                print("Save to CD entity " + pManagedObject.name!)
            }
            
        }
        
    }
        
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
       func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
           tableView.reloadData()
       }
    
       // MARK: - Table view data source
    
       override func numberOfSections(in tableView: UITableView) -> Int {
           // #warning Incomplete implementation, return the number of sections
           return 1
       }
    
       override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
           // #warning Incomplete implementation, return the number of rows
           return frc.sections![section].numberOfObjects
       }
    override func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
    
    
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AnimalCells
        
        // get managed object from frc
        pManagedObject = frc.object(at: indexPath) as? CDSeaCreatures
        // Configure the cell...
        cell.cellLabel?.text = pManagedObject.name
        cell.cellLabel2?.text = pManagedObject.nomenclature
        if pManagedObject.image != ""{
            cell.cellImage?.image = UIImage(named: pManagedObject.image!)
               //        cell.cellImage?.contentMode = UIView.ContentMode.scaleAspectFill
           }
           print(pManagedObject.favourites)
    
           return cell
       }
   
    
    
    
       // Override to support conditional editing of the table view.
       override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
           // Return false if you do not want the specified item to be editable.
           return true
       }
    
    
    
       // Override to support editing the table view.
       override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
           let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! AnimalCells
           if editingStyle == .delete {
               // get from frc the object to delete
               pManagedObject = frc.object(at: indexPath) as? CDSeaCreatures
               
               // context deletes the object
               context.delete(pManagedObject)
               
               // context saves
               do{
                   try context.save()
               }catch{
                   
               }
           }
           
       }
        
    
    // MARK: - Navigation
   

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segue1"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as? AnimalViewController
            
            // get the index path from sender
            let indexPath = tableView.indexPath(for: (sender as? UITableViewCell)!)
            
            // get the managed object from frc
            pManagedObject = frc.object(at: indexPath!) as? CDSeaCreatures
            
            
            // Pass the selected object to the new view controller.
            destinationController?.pManagedObject = pManagedObject
            
        }
        if segue.identifier == "favouritesSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as? FavouritesTableViewController
            
            // get the index path from sender
           // let indexPath = tableView.indexPath(for: (sender as? UIButton)!)
            
            // get the managed object from frc
            //pManagedObject = frc.object(at: indexPath!) as? CDSeaCreatures
            
            // Pass the selected object to the new view controller.
            destinationController?.pManagedObject = pManagedObject
            
        }
        
    }
        //MARK: - image methods
        func getImage(name:String)->UIImage{
            // get the image name from documents
            let imagePath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(name)
            let image = UIImage(contentsOfFile: imagePath)
            return image ?? UIImage(named:pManagedObject.image!)!
        }
}

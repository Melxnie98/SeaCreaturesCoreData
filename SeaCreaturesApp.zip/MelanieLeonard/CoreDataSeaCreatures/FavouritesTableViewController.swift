//
//  AnimalsTableViewController.swift
//  SeaCreatures.app
//
//  Created by Melanie Kate Leonard on 27/02/2023.
//

import UIKit
import CoreData

class FavouriteCells:UITableViewCell{
    
    
    @IBOutlet weak var cellLabel: UILabel!
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var cellLabel2: UILabel!
    
    
    
}

class FavouritesTableViewController: UITableViewController, NSFetchedResultsControllerDelegate{
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext

    var pManagedObject : CDSeaCreatures!
    var newFrc : NSFetchedResultsController<NSFetchRequestResult>!
    var animalsData : [CDSeaCreatures]!
    var pEntity : NSEntityDescription!
    
    func fetchRequest() -> NSFetchRequest<NSFetchRequestResult>{
        // create a request
       
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Animal")
        
        
        // give the predicates if any
        request.predicate = NSPredicate(format: "favourites == %@", NSNumber(value: true))
        
        
        // sort the results
        let sorting1 = NSSortDescriptor(key: "name", ascending: true)
        let sorting2 = NSSortDescriptor(key: "nomenclature", ascending: true)
        let sorting3 = NSSortDescriptor(key: "favourites", ascending: true)
        
        request.sortDescriptors = [sorting1, sorting2,sorting3]
        return request
    }
     
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "My Favourites"
        newFrc = NSFetchedResultsController(fetchRequest: fetchRequest(), managedObjectContext: context, sectionNameKeyPath: nil, cacheName: nil)
        newFrc.delegate = self
        do{
            try newFrc.performFetch()
        }catch{
            print("frc cannot fetch")
        }
        if newFrc.sections![0].numberOfObjects > 0 {
            print("You have favourites data.")
        }else{
            print("No Stored Favourites")
        }
        
        
    }
        
 
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
       func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
           tableView.reloadData()
       }
    
    
       // MARK: - Table view data source
    
       override func numberOfSections(in tableView: UITableView) -> Int {
           // #warning Incomplete implementation, return the number of sections
           return 1
       }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return newFrc.sections![section].numberOfObjects
        }
   
    
       override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
           let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! FavouriteCells
    
           // get managed object from frc
           pManagedObject = newFrc.object(at: indexPath) as? CDSeaCreatures
           
    
           // Configure the cell...
           cell2.cellLabel?.text = pManagedObject.name
           cell2.cellLabel2?.text = pManagedObject.nomenclature
           if pManagedObject.image != ""{
               cell2.cellImage?.image = UIImage(named: pManagedObject.image!)
               //        cell.cellImage?.contentMode = UIView.ContentMode.scaleAspectFill
           }
           return cell2
       }
   
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        80
    }
    
       // Override to support conditional editing of the table view.
       override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
           // Return false if you do not want the specified item to be editable.
           return true
       }
   
    
       // Override to support editing the table view.
       override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
           //let cell2 = tableView.dequeueReusableCell(withIdentifier: "cell2", for: indexPath) as! AnimalCells
           if editingStyle == .delete {
               // get from frc the object to delete
               pManagedObject = newFrc.object(at: indexPath) as? CDSeaCreatures
    
               // context deletes the object
               context.delete(pManagedObject)
    
               // context saves
               do{
                   try context.save()
               }catch{
    
               }
               // eventually reload
           }
       }
    
    // MARK: - Navigation

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "favSegue"{
            // Get the new view controller using segue.destination.
            let destinationController = segue.destination as? AnimalViewController
            
            // get the index path from sender
            let indexPath = tableView.indexPath(for: (sender as? UITableViewCell)!)
            
            // get the managed object from frc
            pManagedObject = newFrc.object(at: indexPath!) as? CDSeaCreatures
            
            // Pass the selected object to the new view controller.
            destinationController?.pManagedObject = pManagedObject
            
        }
    }
        //MARK: - image methods
        func getImage(name:String)->UIImage{
            // get the image name from documents
            let imagePath = (NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString).appendingPathComponent(name)
            let image = UIImage(contentsOfFile: imagePath)
            return image ?? UIImage(named:pManagedObject.image!)!
        }
}

For this assignment I created an xcode Core Data app that acts as a lookup tool for Sea creatures. There are preloaded sea creatures and the user can then add update or delete the sea creatures as they wish


Features:

- Core data:
The Sea creatures are stored in the CDSeaCreatures Entity along with all of the information previously stored in the  XML file. Rather than using two different entities I added a boolean favourites attribute which can be either on or off, meaning that when items are edited/deleted the user only has to do it once, even if it is done from the favourites table.

-XML Parsing:
The tableview onload checks to see if there is already data , if not it parses the xml file from the last assignment into the app to create entities.

-Delete:
Items can be deleted by swiping in the table view from right to left

-Add:
New items can be added by clicking the plus on the top right of the table view screen

-Update:
Items can be updated from the second screen, using the edit button on the top right

-Favourites:
Items can be added and removed from favourites using the UISwitch in the second page. To view just the Favourites, you can click on the favourites button at the top of the first table view controller AnimalViewController- which will take you to a new table view controller populated with only items that have the boolean true , this was done using pManagedObject.favourites.toggle(). I originally tried had the favourites switch on the individual cells in the first table view but they just looked messy

- Video View 
In the previous assignment this was done using stored videos, however I decided to use YouTube videos for this assignment for the purpose of storage and file size

- App Icon
I created the app icon using gimp - I imported an image of the sea - a magnifying glass and a simple name  "Sea Creatures Finder" I then exported the image and added it to  the projects assets folder as AppIcon 

- Buttons:
Created the buttons using an image which I also edited using Gimp, I fount a sea green button online and set the shape to capsule

-Theme Switch-
The theme switch is implemented using the Theme Class where the colours are defined- they can be seen in assets - there is a light and a dark mode which you can flick between using Shift + Command + A or by clicking features in the simulator menu and then toggle appearance 

- Table View: Cells
For the table view I used custom cells in order to display an Image alongside data - I chose a font that reminded me of education as it looked a little boring in the regular font and an italic font fortunderneath so the hierarchy was easy to observe. 

- Scroll view   
Two of the views - Animal view and details view have scroll views to enable scrolling when the device is put sideways - this allows the content to be seen rather than squished and distorted - in both of the views I decided to leave the buttons out of the scroll view so the user could access them no matter where in the scroll they were.

-Animal View 
This view picks its title based off the selection from the table view , it contains a large image of the chosen animal alongside two labels which state the species  endangerment status and whether or not they are harmful to humans - these two labels are contained within a view as i found it easier to constrain this way. It also has two buttons leading to different screens - one for more info and one that takes you to the web page- the buttons are also constrained within a view in order to make constraining them within the scroll view easier. More info leads to details view and web info leads to web view

- Details View 
This View contains more information from the XML file including habitat info- Lifespan and a more detailed description of the animal. This screen was the most difficult to constrain for scroll view as there were so many labels It also has two buttons - one that leads to web view as Animal view does and another that leads to a different web view - video - which brings the user to a Youtube video about the animal 

- Web view 
This is a WebKit view - i had originally embedded it in the app so that it looked like the web page was still in the app - it had the same border green colour but eventually decided to set it to take up the whole screen. The URL is seen at the top of the screen 
